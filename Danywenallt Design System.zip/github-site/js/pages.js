function PageHead({ eyebrow, title, lead }) {
  return (
    <section style={{ padding: '88px 0 56px' }}>
      <div className="dw-wrap" style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
        <div className="dw-eyebrow" style={{ color: 'var(--dw-sage)' }}>{eyebrow}</div>
        <h1 className="dw-h1" style={{ maxWidth: 1000 }}>{title}</h1>
        {lead && <p className="dw-lead" style={{ maxWidth: 680, color: 'var(--dw-graphite)' }}>{lead}</p>}
      </div>
    </section>
  );
}

const DW_FACILITIES = ['Self-catering kitchen', 'Group meals & packed lunches', 'Licensed bar', 'Dining room', 'Lounge with TV', 'Large garden & BBQ area', 'Drying room', 'Cycle store', 'Free WiFi in social spaces', 'Free parking & minibus parking', 'EV charger', 'Wheelchair accessible'];

function Stay({ go }) {
  return (
    <>
      <PageHead eyebrow="The house" title="A converted Welsh farmhouse, all yours." lead="Original stonework, characterful beams and an old fireplace — with a well-equipped kitchen and room for your whole group to gather." />
      <div className="dw-wrap">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))', gap: 16 }}>
          <Photo id="stay-exterior" label="Farmhouse exterior" style={{ gridColumn: '1 / -1', aspectRatio: '21/9' }} />
          <Photo id="home-dining" label="Dining room" style={{ aspectRatio: '4/3' }} />
          <Photo id="home-lounge" label="Lounge" style={{ aspectRatio: '4/3' }} />
          <Photo id="stay-bedroom" label="Bunk room" style={{ aspectRatio: '4/3' }} />
          <Photo id="stay-bathroom" label="Bathroom / showers" style={{ aspectRatio: '4/3' }} />
          <Photo id="stay-kitchen" label="Kitchen" style={{ aspectRatio: '4/3' }} />
          <Photo id="stay-bed3" label="3-bed room" style={{ aspectRatio: '4/3' }} />
          <Photo id="stay-bed" label="Bedroom" style={{ aspectRatio: '4/3' }} />
          <Photo id="stay-bed4b" label="4-bed room" style={{ aspectRatio: '4/3' }} />
        </div>
      </div>
      <section className="dw-section">
        <div className="dw-wrap dw-split">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <h2 className="dw-h3">Sleeping</h2>
            <p className="dw-body" style={{ color: 'var(--dw-graphite)' }}>Most bedrooms are dormitory-style with bunk beds. We keep your group's rooms together and never ask you to share with anyone outside your party. Upgrade to sole use of a floor or the entire house.</p>
          </div>
          <div className="dw-grid-2" style={{ gap: 16 }}>
            {[['Exclusive hire', 'The entire house for up to 35 guests. Dogs welcome on exclusive hire.'], ['Group booking', 'Serviced stays for 16–35 people, from room only to full board.']].map(([t, b]) => (
              <div key={t} style={{ background: '#fff', border: '1px solid var(--dw-smoke)', borderRadius: 'var(--radius-card)', padding: 28, display: 'flex', flexDirection: 'column', gap: 12 }}>
                <h3 className="dw-h4" style={{ fontSize: 26 }}>{t}</h3>
                <p className="dw-body" style={{ color: 'var(--dw-graphite)', fontSize: 17 }}>{b}</p>
                <button onClick={() => go('prices')} style={{ all: 'unset', cursor: 'pointer', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 8, marginTop: 8 }}>See prices <Arrow /></button>
              </div>
            ))}
          </div>
        </div>
      </section>
      <HistoryTeaser go={go} />
      <section className="dw-section" style={{ background: 'var(--dw-cloud)' }}>
        <div className="dw-wrap dw-split">
          <h2 className="dw-h3">Everything a group needs.</h2>
          <ul className="dw-list dw-body" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))', columnGap: 32 }}>
            {DW_FACILITIES.map((f) => <li key={f}>{f}</li>)}
          </ul>
        </div>
      </section>
      <BookBand go={go} />
    </>
  );
}

function Location({ go }) {
  return (
    <>
      <PageHead eyebrow="Getting here" title="Halfway up a quiet valley in the Brecon Beacons." lead="Secluded, but never far from anything. Wooded slopes, high peaks, waterfalls and trails start at the front door." />
      <div className="dw-wrap">
        <div className="dw-grid-2" style={{ gap: 16 }}>
          <div className="dw-media" style={{ aspectRatio: '4/3' }}>
            <iframe title="Map" src="https://www.openstreetmap.org/export/embed.html?bbox=-3.36%2C51.85%2C-3.24%2C51.90&layer=mapnik&marker=51.8766111%2C-3.2977676" style={{ border: 0, width: '100%', height: '100%', position: 'absolute', inset: 0, filter: 'grayscale(.6) sepia(.15)' }}></iframe>
          </div>
          <div style={{ background: 'var(--dw-green)', color: 'var(--dw-cream)', borderRadius: 'var(--radius-card)', padding: 'clamp(28px,4cqw,48px)', display: 'flex', flexDirection: 'column', gap: 28 }}>
            <div className="dw-h4">Danywenallt<br />Talybont-on-Usk, Brecon<br />Powys LD3 7YS</div>
            <ul className="dw-list" style={{ fontSize: 15 }}>
              {[['OS Map', '161'], ['Grid ref', 'SO107206'], ['Lat / Lng', '51.8766, −3.2978'], ['what3words', 'wheat.ropes.deal']].map(([k, v]) => <li key={k} style={{ borderColor: 'rgba(242,240,229,.2)' }}><span style={{ opacity: .7 }}>{k}</span><span>{v}</span></li>)}
            </ul>
          </div>
        </div>
      </div>
      <section className="dw-section">
        <div className="dw-wrap dw-grid-3" style={{ gap: 40 }}>
          {[['By car', 'Free parking on site, including minibus parking and a free EV charger. Coach parking nearby.'], ['By public transport', 'Nearest mainline station is Abergavenny. Local buses run to Talybont-on-Usk; ask us about the last stretch up the valley.'], ['On arrival', '24-hour access after check-in. Full mobile coverage and WiFi in the social spaces.']].map(([t, b]) => (
            <div key={t} style={{ display: 'flex', flexDirection: 'column', gap: 12, borderTop: '1.5px solid var(--dw-green)', paddingTop: 20 }}>
              <h3 className="dw-h4" style={{ fontSize: 26 }}>{t}</h3>
              <p className="dw-body" style={{ color: 'var(--dw-graphite)' }}>{b}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="dw-section" style={{ background: 'var(--dw-cloud)' }}>
        <div className="dw-wrap" style={{ display: 'flex', flexDirection: 'column', gap: 40 }}>
          <h2 className="dw-h3">On the doorstep</h2>
          <div className="dw-grid-4">
            {[['loc-waterfalls', 'Waterfall walks'], ['loc-taff', 'Taff Trail cycling'], ['loc-water', 'Sailing & boating'], ['loc-llangorse', 'Llangorse climbing & zip line']].map(([id, l]) => (
              <div key={id} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}><Photo id={id} label={l} style={{ aspectRatio: '1/1' }} /><div style={{ fontWeight: 500 }}>{l}</div></div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

function Prices() {
  return (
    <>
      <PageHead eyebrow="Prices & availability" title="Pick your dates." lead="Choose exclusive hire or a serviced group stay, select your nights and see the price. You'll finish booking securely with YHA." />
      <div className="dw-wrap" style={{ paddingBottom: 96 }}><BookingWidget /></div>
      <section className="dw-section" style={{ background: 'var(--dw-cloud)' }}>
        <div className="dw-wrap dw-grid-2" style={{ gap: 16 }}>
          {[['Exclusive hire', [['Sun–Thu', `from ${gbp(DW_PRICES.exclusive.weekday)} / night`], ['Fri & Sat', `from ${gbp(DW_PRICES.exclusive.weekend)} / night`], ['Minimum stay', '2 nights'], ['Guests', 'Up to 35']]], ['Group booking', [['Bed', `from ${gbp(DW_PRICES.group.pp)} pp / night`], ['Bed & breakfast', '+£8 pp / night'], ['Half board', '+£19 pp / night'], ['Full board', '+£27 pp / night']]]].map(([t, rows]) => (
            <div key={t} style={{ background: '#fff', borderRadius: 'var(--radius-card)', padding: 32, display: 'flex', flexDirection: 'column', gap: 16 }}>
              <h3 className="dw-h4">{t}</h3>
              <ul className="dw-list dw-body" style={{ fontSize: 17 }}>{rows.map(([k, v]) => <li key={k}><span style={{ color: 'var(--dw-graphite)' }}>{k}</span><span>{v}</span></li>)}</ul>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

const DW_FAQ = [
  ['Can we have the whole place to ourselves?', 'Yes. Danywenallt is offered on an exclusive hire basis, so you get the entire house. Serviced group stays for 16–35 people are also available.'],
  ['What are the bedrooms like?', 'Most are dormitory-style with bunk beds. Your group’s rooms are kept together and you’ll never share with anyone outside your party.'],
  ['Is food included?', 'Choose from self-catering, bed & breakfast, half board or full board. Vegetarian options are available and we aim to cater for special dietary requests.'],
  ['Can we bring a dog?', 'Pets are welcome only on exclusive hire. Assistance dogs are always welcome — please tell us when you book.'],
  ['Is it suitable for school trips?', 'Yes. Danywenallt holds a Learning Outside the Classroom Quality Badge (105537): audited risk assessments, verified insurance and quality-checked safety logs.'],
  ['Is there parking and WiFi?', 'Free on-site parking including minibuses, a free EV charger, and free WiFi in the social spaces.'],
  ['Who handles the booking?', 'Danywenallt is a YHA partner. You choose dates and see prices here, then complete payment securely on yha.org.uk.'],
];

function FAQ({ go }) {
  const [open, setOpen] = React.useState(0);
  return (
    <>
      <PageHead eyebrow="FAQ" title="Good to know before you go." />
      <div className="dw-wrap dw-split" style={{ paddingBottom: 120 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }} className="dw-hide-m">
          <p className="dw-body" style={{ color: 'var(--dw-graphite)' }}>Can’t see your question?</p>
          <div><Btn kind="ghost" onClick={() => go('contact')}>Get in touch</Btn></div>
        </div>
        <div style={{ borderBottom: '1px solid var(--dw-smoke)' }}>
          {DW_FAQ.map(([q, a], i) => (
            <div key={q} className="dw-faq">
              <button onClick={() => setOpen(open === i ? -1 : i)} aria-expanded={open === i}>{q}<span style={{ fontSize: 26, fontWeight: 400, lineHeight: 1 }}>{open === i ? '−' : '+'}</span></button>
              {open === i && <p className="dw-body" style={{ color: 'var(--dw-graphite)', paddingBottom: 28, maxWidth: 640 }}>{a}</p>}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function Contact() {
  const [sent, setSent] = React.useState(false);
  return (
    <>
      <PageHead eyebrow="Contact" title="Tell us about your group." lead="Dates, numbers, what you’d like to get up to — we’ll come back to you within one working day." />
      <div className="dw-wrap dw-split" style={{ paddingBottom: 120 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <ul className="dw-list dw-body">
            <li><span style={{ color: 'var(--dw-graphite)' }}>Phone</span><span>0345 371 9548</span></li>
            <li><span style={{ color: 'var(--dw-graphite)' }}>Address</span><span style={{ textAlign: 'right' }}>Brecon, Powys LD3 7YS</span></li>
          </ul>
          <Photo id="contact-photo" label="Group in the valley" style={{ aspectRatio: '4/3' }} />
        </div>
        {sent ? (
          <div style={{ background: 'var(--dw-green)', color: 'var(--dw-cream)', borderRadius: 'var(--radius-card)', padding: 40, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <h2 className="dw-h3">Thanks — we’re on it.</h2>
            <p className="dw-body" style={{ opacity: .85 }}>We’ll reply within one working day.</p>
          </div>
        ) : (
          <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 16 }}>
            <label className="dw-field">Name<input required placeholder="Your name" /></label>
            <label className="dw-field">Email<input required type="email" placeholder="you@example.com" /></label>
            <label className="dw-field">Group type<select><option>Friends & family</option><option>Team / company</option><option>School</option><option>Other</option></select></label>
            <label className="dw-field">Group size<input type="number" min="1" max="35" placeholder="e.g. 24" /></label>
            <label className="dw-field" style={{ gridColumn: '1 / -1' }}>Message<textarea rows="5" placeholder="Dates, activities, catering…"></textarea></label>
            <div><Btn arrow type="submit">Send enquiry</Btn></div>
          </form>
        )}
      </div>
    </>
  );
}

Object.assign(window, { Stay, Location, Prices, FAQ, Contact, PageHead });
