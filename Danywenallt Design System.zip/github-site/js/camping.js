const DW_CAMP_INCLUDES = ['Hot showers and toilets in the farmhouse', 'Self-catering kitchen and dining room', 'Drying room for wet kit', 'Cycle store', 'BBQ area and outdoor seating', 'Water refill station', 'Free parking, including minibuses'];

function Camping({ go }) {
  return (
    <>
      <PageHead eyebrow="Camping" title="Pitch up in the valley. Come in for a hot shower." lead="Sleep under canvas in the farmhouse grounds, with the comforts of the house close at hand and the trails starting at the gate." />
      <div className="dw-wrap">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))', gap: 16 }}>
          <Photo id="camp-hero" label="Tents in the grounds, valley behind" style={{ gridColumn: '1 / -1', aspectRatio: '21/9' }} />
          <Photo id="camp-pitch" label="Pitch area" style={{ aspectRatio: '4/3' }} />
          <Photo id="camp-fire" label="Evening round the BBQ" style={{ aspectRatio: '4/3' }} />
          <Photo id="stay-bathroom" label="Bathroom / showers" style={{ aspectRatio: '4/3' }} />
          <Photo id="camp-morning" label="Morning in the valley" style={{ aspectRatio: '4/3' }} />
        </div>
      </div>
      <section className="dw-section">
        <div className="dw-wrap dw-split">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <h2 className="dw-h3">Outdoors by night, comfort by day.</h2>
            <p className="dw-body" style={{ color: 'var(--dw-graphite)' }}>Camping keeps your group close to the hills and the cost down. The farmhouse stays your basecamp — somewhere to cook, dry off, warm up and gather.</p>
          </div>
          <ul className="dw-list dw-body">{DW_CAMP_INCLUDES.map((f) => <li key={f}>{f}</li>)}</ul>
        </div>
      </section>
      <section className="dw-section" style={{ background: 'var(--dw-cloud)' }}>
        <div className="dw-wrap" style={{ display: 'flex', flexDirection: 'column', gap: 40 }}>
          <h2 className="dw-h3">Who it's for</h2>
          <div className="dw-grid-3" style={{ gap: 40 }}>
            {[['Schools & youth groups', 'Expedition practice, DofE and outdoor learning, with the house for meals and kit.'], ['Friends & families', 'A weekend under canvas without giving up a proper shower.'], ['Add to a house booking', 'Overflow space when your group is bigger than the beds.']].map(([t, b]) => (
              <div key={t} style={{ display: 'flex', flexDirection: 'column', gap: 12, borderTop: '1.5px solid var(--dw-green)', paddingTop: 20 }}>
                <h3 className="dw-h4" style={{ fontSize: 26 }}>{t}</h3>
                <p className="dw-body" style={{ color: 'var(--dw-graphite)' }}>{b}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="dw-section--tight">
        <div className="dw-wrap">
          <div style={{ background: 'var(--dw-green)', color: 'var(--dw-cream)', borderRadius: 'var(--radius-card)', overflow: 'hidden', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))' }}>
            <div style={{ padding: 'clamp(28px,4cqw,56px)', display: 'flex', flexDirection: 'column', gap: 24, justifyContent: 'center' }}>
              <h2 className="dw-h3">Planning a camping trip?</h2>
              <p className="dw-body" style={{ opacity: .85 }}>Tell us your dates and group size and we'll confirm pitches and prices.</p>
              <div><Btn kind="light" arrow onClick={() => go('contact')}>Enquire about camping</Btn></div>
            </div>
            <Pattern tone="cream" style={{ minHeight: 280 }} />
          </div>
        </div>
      </section>
    </>
  );
}

Object.assign(window, { Camping });
