const DW_HISTORY = [
  ['c.1100', 'A Norman manor', 'Wenallt manor takes shape as part of the Lordship of Pencelli, in the parish of Llanddetty and its church of St Detta.'],
  ['1730s', 'Tyr dan y Wenallt', 'The farm appears in written records: William Morgan’s will mentions a £100 mortgage on Danyrwenallt.'],
  ['1815', 'The tramroad', 'The Brinore Tramroad is finished, carrying limestone, coal and iron down the valley to the canal at Talybont.'],
  ['1863', 'The railway', 'The Brecon & Merthyr railway opens. Its line is now the Taff Trail, which guests still cycle from the door.'],
  ['1893', 'A new owner', 'Tir Danywenallt, otherwise Danywennallt Uchaf Farm, passes to Samuel Williams, a Talybont provision merchant. Sheep graze the slopes of Tor y Foel.'],
  ['1912', 'Sold for £1,075', 'Samuel Williams sells the farm to William Jones Davies, a coal merchant from Merthyr Tydfil.'],
  ['1932–39', 'The reservoir', 'Newport Corporation dams the valley. Seventeen homes and farms are taken, and Talybont Reservoir officially opens in 1939.'],
  ['1958', 'Farming on', 'The Williams family farm Danywenallt Uchaf, Llwynbedw and Berthlwyd as tenants: more than 920 acres beside the new water.'],
  ['2005', 'A place to learn', 'The farmhouse opens as a National Park study centre and hostel, run with YHA.'],
  ['2026', 'A new chapter', 'Danywenallt Ltd takes over as a YHA Partner: a modern Welsh basecamp in a very old place.'],
];

function History({ go }) {
  return (
    <>
      <PageHead eyebrow="Our story" title="Below the fair wooded hillside." lead="Dan-y-wenallt: dan, below; gwen, white or fair; allt, wooded slope. The name has described this spot in Glyn Collwn for centuries." />
      <div className="dw-wrap">
        <Photo id="history-hero" label="The valley and reservoir" style={{ aspectRatio: '21/9' }} />
      </div>
      <section className="dw-section">
        <div className="dw-wrap dw-split">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20, position: 'sticky', top: 120 }}>
            <h2 className="dw-h3">Nine centuries in one valley.</h2>
            <p className="dw-body" style={{ color: 'var(--dw-graphite)' }}>Manor, farm, tramroad country, then a valley reshaped by water. Danywenallt has been a working part of this landscape for a very long time.</p>
          </div>
          <ol style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column' }}>
            {DW_HISTORY.map(([y, t, b]) => (
              <li key={y} style={{ display: 'grid', gridTemplateColumns: 'minmax(88px,140px) minmax(0,1fr)', gap: 24, padding: '28px 0', borderTop: '1px solid var(--dw-smoke)' }}>
                <div className="dw-h4" style={{ color: 'var(--dw-sage)', fontSize: 'clamp(22px,2.2cqw,30px)' }}>{y}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <h3 style={{ fontSize: 20, fontWeight: 600 }}>{t}</h3>
                  <p className="dw-body" style={{ color: 'var(--dw-graphite)' }}>{b}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>
      <section className="dw-section--tight">
        <div className="dw-wrap">
          <div style={{ background: 'var(--dw-green)', color: 'var(--dw-cream)', borderRadius: 'var(--radius-card)', overflow: 'hidden', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))' }}>
            <div style={{ padding: 'clamp(28px,4cqw,56px)', display: 'flex', flexDirection: 'column', gap: 20, justifyContent: 'center' }}>
              <div className="dw-eyebrow" style={{ opacity: .7 }}>Look out for it</div>
              <h2 className="dw-h3">The old mill wheel.</h2>
              <p className="dw-body" style={{ opacity: .85 }}>Felin Newydd mill was demolished when the reservoir came, but its iron water wheel survives by the mesh bridge below the Danywenallt drive.</p>
            </div>
            <Pattern tone="cream" style={{ minHeight: 280 }} />
          </div>
        </div>
      </section>
      <section style={{ padding: '24px 0 96px' }}>
        <div className="dw-wrap">
          <p className="dw-caption" style={{ maxWidth: 760, fontSize: 13 }}>Sources: Powys Archives (B/D/WWA/2), Coflein, talybontonusk.wales, the Blaenau Gwent Heritage Forum and local family history. Do you know more? We’d love to hear it. <button onClick={() => go('contact')} style={{ all: 'unset', cursor: 'pointer', textDecoration: 'underline', color: 'var(--dw-green)' }}>Get in touch</button></p>
        </div>
      </section>
    </>
  );
}

function HistoryTeaser({ go }) {
  return (
    <section className="dw-section" style={{ paddingTop: 0 }}>
      <div className="dw-wrap dw-grid-2" style={{ gap: 40, alignItems: 'center' }}>
        <Photo id="history-hero" label="The valley and reservoir" style={{ aspectRatio: '4/3' }} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div className="dw-eyebrow" style={{ color: 'var(--dw-sage)' }}>Our story</div>
          <h2 className="dw-h3">A farm since the 1100s.</h2>
          <p className="dw-body" style={{ color: 'var(--dw-graphite)' }}>From a Norman manor to a sheep farm on Tor y Foel to a valley reshaped by Talybont Reservoir: the stonework here has stories in it.</p>
          <button onClick={() => go('history')} style={{ all: 'unset', cursor: 'pointer', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 8 }}>Read the history <Arrow /></button>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { History, HistoryTeaser });
