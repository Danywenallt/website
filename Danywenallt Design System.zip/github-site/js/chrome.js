const A = './assets';
const NAV = [['stay', 'The house'], ['camping', 'Camping'], ['history', 'Our story'], ['location', 'Getting here'], ['prices', 'Prices & availability'], ['faq', 'FAQ'], ['contact', 'Contact']];
const NAV_TOP = [['stay', 'The house'], ['camping', 'Camping'], ['prices', 'Prices & availability'], ['contact', 'Contact'], ['about', 'About', [['history', 'Our story'], ['location', 'Getting here'], ['faq', 'FAQ']]]];

function NavMenu({ label, items, page, nav, overlay }) {
  const [open, setOpen] = React.useState(false);
  const active = items.some(([k]) => k === page);
  return (
    <div style={{ position: 'relative' }} onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      <button aria-expanded={open} aria-current={active ? 'page' : undefined} onClick={() => setOpen(!open)} style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>{label}<span style={{ fontSize: 10, transform: open ? 'rotate(180deg)' : 'none', transition: 'transform .2s' }}>▾</span></button>
      {open && (
        <div style={{ position: 'absolute', top: '100%', left: -16, paddingTop: 10, zIndex: 30 }}>
          <div style={{ background: 'var(--dw-cream)', color: 'var(--dw-green)', borderRadius: 'var(--radius-card)', border: '1px solid var(--dw-smoke)', padding: 8, minWidth: 200, display: 'flex', flexDirection: 'column' }}>
            {items.map(([k, l]) => <button key={k} onClick={() => { setOpen(false); nav(k); }} style={{ padding: '10px 12px', borderRadius: 8, border: 0, background: page === k ? 'var(--dw-cloud)' : 'transparent', color: 'var(--dw-green)' }}>{l}</button>)}
          </div>
        </div>
      )}
    </div>
  );
}

function Logo({ tone = 'green', variant = 'horizontal', height = 22 }) {
  return <img src={`${A}/logos/danywenallt-${variant}-${tone}.svg`} alt="Danywenallt" style={{ height, display: 'block' }} />;
}

function Arrow({ size = 20, style }) {
  const { ArrowRight } = window.DanywenalltDesignSystem_d9b682 || {};
  if (!ArrowRight) return null;
  return <span style={{ display: 'inline-flex', transform: `scale(${size / 20})`, ...style }}><ArrowRight style={{ color: 'currentColor' }} /></span>;
}

function Btn({ kind = 'primary', children, arrow, ...p }) {
  return <button className={`dw-btn dw-btn--${kind}`} {...p}>{children}{arrow && <Arrow />}</button>;
}

const DW_PHOTOS = {
  'hero-valley': 'valley-distant.webp', 'stay-exterior': 'exterior.webp', 'home-dining': 'dining.webp', 'home-lounge': 'front-room.jpg',
  'stay-bedroom': 'bedroom-4-bed.webp', 'stay-bathroom': 'shower.webp', 'stay-kitchen': 'kitchen.webp', 'stay-bed3': 'bedroom-3-bed.webp',
  'stay-bed': 'bedroom.webp', 'stay-bed4b': 'bedroom-4-bed-b.webp', 'home-activity': 'school-trip.jpg', 'aud-friends': 'exterior-seating.webp',
  'aud-teams': 'dining-2.webp', 'aud-schools': 'school-trip.jpg', 'camp-hero': 'orchard-camping.jpg', 'camp-pitch': 'exterior-seating.webp',
  'camp-morning': 'valley-distant.webp', 'contact-photo': 'exterior.webp', 'history-hero': 'valley-distant.webp',
};

function Photo({ id, label, style, radius = true }) {
  const src = DW_PHOTOS[id] ? `${A}/photos/${DW_PHOTOS[id]}` : undefined;
  return (
    <div className="dw-media" style={{ borderRadius: radius ? undefined : 0, ...style }}>
      <image-slot id={id} shape="rect" placeholder={label} src={src} alt={label} style={{ position: 'absolute', inset: 0 }}></image-slot>
    </div>
  );
}

function Header({ page, go, overlay }) {
  const [open, setOpen] = React.useState(false);
  const tone = overlay ? 'cream' : 'green';
  const nav = (k) => { setOpen(false); go(k); };
  return (
    <header className={`dw-header ${overlay ? 'dw-header--overlay' : ''}`}>
      <div className="dw-wrap dw-header__in">
        <button onClick={() => nav('home')} style={{ all: 'unset', cursor: 'pointer' }} aria-label="Home"><Logo tone={tone} height={20} /></button>
        <nav className="dw-nav">
          {NAV_TOP.map(([k, l, sub]) => sub ? <NavMenu key={k} label={l} items={sub} page={page} nav={nav} overlay={overlay} /> : <button key={k} aria-current={page === k ? 'page' : undefined} onClick={() => nav(k)}>{l}</button>)}
        </nav>
        <div className="dw-header__cta"><Btn kind={overlay ? 'light' : 'primary'} onClick={() => nav('prices')} style={{ height: 44 }}>Check availability</Btn></div>
        <button className="dw-burger dw-btn dw-btn--ghost" style={{ height: 40, padding: '0 16px' }} onClick={() => setOpen(true)}>Menu</button>
      </div>
      {open && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 50, background: 'var(--dw-green)', color: 'var(--dw-cream)', display: 'flex', flexDirection: 'column', padding: 20, gap: 32 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', height: 28 }}>
            <Logo tone="cream" height={18} />
            <button className="dw-btn dw-btn--ghost" style={{ height: 40, padding: '0 16px' }} onClick={() => setOpen(false)}>Close</button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            {[['home', 'Home'], ...NAV].map(([k, l]) => <button key={k} onClick={() => nav(k)} style={{ all: 'unset', cursor: 'pointer', fontSize: 34, fontWeight: 500, padding: '8px 0' }}>{l}</button>)}
          </div>
          <div style={{ marginTop: 'auto' }}><Btn kind="light" arrow onClick={() => nav('prices')} style={{ width: '100%', justifyContent: 'center' }}>Check availability</Btn></div>
        </div>
      )}
    </header>
  );
}

function Footer({ go }) {
  return (
    <footer className="dw-footer">
      <div className="dw-wrap" style={{ padding: '80px 40px 40px', display: 'flex', flexDirection: 'column', gap: 64 }}>
        <div className="dw-split" style={{ alignItems: 'end' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
            <Logo tone="cream" variant="stacked" height={96} />
          </div>
          <div className="dw-grid-3" style={{ fontSize: 15, lineHeight: 1.7 }}>
            <div><div className="dw-eyebrow" style={{ marginBottom: 12, opacity: .7 }}>Visit</div>Danywenallt<br />Talybont-on-Usk<br />Brecon, Powys LD3 7YS</div>
            <div><div className="dw-eyebrow" style={{ marginBottom: 12, opacity: .7 }}>Talk to us</div>0345 371 9548<br />what3words: wheat.ropes.deal</div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}><div className="dw-eyebrow" style={{ marginBottom: 12, opacity: .7 }}>Explore</div>
              {NAV.map(([k, l]) => <button key={k} onClick={() => go(k)} style={{ all: 'unset', cursor: 'pointer' }}>{l}</button>)}
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 24, flexWrap: 'wrap', borderTop: '1px solid rgba(242,240,229,.2)', paddingTop: 28, fontSize: 13 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <img src={`${A}/logos/yha-partner.png`} alt="YHA Partner" style={{ height: 52, display: 'block' }} />
            <span style={{ maxWidth: 320, opacity: .8 }}>Danywenallt is a YHA partner hostel. Bookings are completed securely on yha.org.uk.</span>
          </div>
          <span style={{ opacity: .6 }}>© 2026 Danywenallt</span>
        </div>
      </div>
    </footer>
  );
}

function Pattern({ tone = 'cream', style, children }) {
  return <div className={`dw-pattern dw-pattern--${tone}`} style={style}>{children}</div>;
}

Object.assign(window, { Logo, Arrow, Btn, Photo, Header, Footer, Pattern, NAV, DW_ASSETS: A });
