const DW_TODAY = new Date(2026, 9, 20);
const DW_PRICES = {
  exclusive: { weekday: 720, weekend: 890, label: 'Exclusive hire', note: 'Whole house, up to 35 guests' },
  group: { pp: 29, label: 'Group booking', note: 'Serviced stay for 16–35 people' },
};
const DW_MEALS = [['none', 'Room only', 0], ['bb', 'Bed & breakfast', 8], ['hb', 'Half board', 19], ['fb', 'Full board', 27]];
const dwKey = (d) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
const dwBooked = (d) => { const n = d.getFullYear() * 400 + d.getMonth() * 31 + d.getDate(); return (n * 7919) % 11 < 3; };
const dwFmt = (d) => d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
const dwDMY = (d) => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
const DW_PARTY = [['males', 'Male', 'Adult'], ['females', 'Female', 'Adult'], ['malesChild', 'Male', 'Under 18'], ['femalesChild', 'Female', 'Under 18']];
const yhaUrl = (s, e, party) => {
  let u = `https://www.yha.org.uk/hostel/yha-brecon-beacons-danywenallt?startDate=${encodeURIComponent(dwDMY(s))}&endDate=${encodeURIComponent(dwDMY(e))}&males=${party.males}&females=${party.females}`;
  if (party.malesChild || party.femalesChild) u += `&malesChild=${party.malesChild}&femalesChild=${party.femalesChild}`;
  return u;
};
const gbp = (n) => '£' + n.toLocaleString('en-GB');

function Calendar({ start, end, onPick }) {
  const [view, setView] = React.useState(new Date(DW_TODAY.getFullYear(), DW_TODAY.getMonth(), 1));
  const first = (view.getDay() + 6) % 7;
  const days = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
  const cells = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => new Date(view.getFullYear(), view.getMonth(), i + 1))];
  const state = (d) => {
    if (d < DW_TODAY) return 'past';
    if (dwBooked(d)) return 'booked';
    if (start && dwKey(d) === dwKey(start)) return 'edge';
    if (end && dwKey(d) === dwKey(end)) return 'edge';
    if (start && end && d > start && d < end) return 'in';
    return 'free';
  };
  const shift = (n) => setView(new Date(view.getFullYear(), view.getMonth() + n, 1));
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <button className="dw-btn dw-btn--ghost" style={{ height: 36, padding: '0 14px' }} onClick={() => shift(-1)} disabled={view <= new Date(DW_TODAY.getFullYear(), DW_TODAY.getMonth(), 1)}>Prev</button>
        <div style={{ fontWeight: 500, fontSize: 18 }}>{view.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}</div>
        <button className="dw-btn dw-btn--ghost" style={{ height: 36, padding: '0 14px' }} onClick={() => shift(1)}>Next</button>
      </div>
      <div className="dw-cal">
        {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => <div key={i} className="dw-cal__h">{d}</div>)}
        {cells.map((d, i) => d ? <button key={i} className="dw-day" data-state={state(d)} onClick={() => { const s = state(d); if (s !== 'past' && s !== 'booked') onPick(d); }}>{d.getDate()}</button> : <div key={i}></div>)}
      </div>
      <div style={{ display: 'flex', gap: 16, fontSize: 13, color: 'var(--dw-graphite)' }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><i style={{ width: 12, height: 12, borderRadius: 3, background: 'var(--dw-green)' }}></i>Selected</span>
        <span style={{ textDecoration: 'line-through' }}>12</span><span style={{ marginLeft: -10 }}>Unavailable</span>
      </div>
    </div>
  );
}

function BookingWidget({ initialMode = 'exclusive' }) {
  const [mode, setMode] = React.useState(initialMode);
  const [start, setStart] = React.useState(null);
  const [end, setEnd] = React.useState(null);
  const [party, setParty] = React.useState({ males: 10, females: 10, malesChild: 0, femalesChild: 0 });
  const g = DW_PARTY.reduce((s, [k]) => s + party[k], 0);
  const bump = (k, n) => setParty((p) => { const v = Math.max(0, p[k] + n); const tot = g - p[k] + v; return tot > 35 ? p : { ...p, [k]: v }; });
  const [meal, setMeal] = React.useState('bb');
  const [handoff, setHandoff] = React.useState(false);

  const pick = (d) => {
    if (!start || end || d <= start) { setStart(d); setEnd(null); return; }
    for (let x = new Date(start); x <= d; x.setDate(x.getDate() + 1)) if (dwBooked(x)) { setStart(d); setEnd(null); return; }
    setEnd(d);
  };
  const nightsList = [];
  if (start && end) for (let x = new Date(start); x < end; x.setDate(x.getDate() + 1)) nightsList.push(new Date(x));
  const nights = nightsList.length;
  const minG = mode === 'group' ? 16 : 1;
  const mealPP = DW_MEALS.find((m) => m[0] === meal)[2];
  let stay = 0;
  if (mode === 'exclusive') stay = nightsList.reduce((s, d) => s + ([5, 6].includes(d.getDay()) ? DW_PRICES.exclusive.weekend : DW_PRICES.exclusive.weekday), 0);
  else stay = nights * g * DW_PRICES.group.pp;
  const food = nights * g * mealPP;
  const minNights = mode === 'exclusive' ? 2 : 1;
  const ok = nights >= minNights && g >= minG;

  if (handoff) return (
    <div style={{ background: 'var(--dw-green)', color: 'var(--dw-cream)', borderRadius: 'var(--radius-card)', padding: 40, display: 'flex', flexDirection: 'column', gap: 20, alignItems: 'flex-start' }}>
      <img src={`${DW_ASSETS}/logos/yha-partner.png`} alt="YHA Partner" style={{ height: 72 }} />
      <div className="dw-h4">Taking you to YHA to finish booking</div>
      <p className="dw-body" style={{ opacity: .85 }}>{DW_PRICES[mode].label} · {dwFmt(start)} – {dwFmt(end)} · {g} guests · {gbp(stay + food)}. Your dates are held for 15 minutes while you complete payment on yha.org.uk.</p>
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <Btn kind="light" arrow onClick={() => window.open(yhaUrl(start, end, party), '_blank')}>Continue to yha.org.uk</Btn>
        <Btn kind="ghost" onClick={() => setHandoff(false)}>Back</Btn>
      </div>
    </div>
  );

  return (
    <div style={{ background: '#fff', borderRadius: 'var(--radius-card)', border: '1px solid var(--dw-smoke)', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))' }}>
      <div style={{ padding: 32, display: 'flex', flexDirection: 'column', gap: 24, borderRight: '1px solid var(--dw-smoke)' }}>
        <div className="dw-seg">
          {['exclusive', 'group'].map((m) => <button key={m} aria-pressed={mode === m} onClick={() => setMode(m)}>{DW_PRICES[m].label}</button>)}
        </div>
        <div className="dw-caption" style={{ marginTop: -12 }}>{DW_PRICES[mode].note}</div>
        <Calendar start={start} end={end} onPick={pick} />
      </div>
      <div style={{ padding: 32, display: 'flex', flexDirection: 'column', gap: 20, background: 'var(--dw-cream)', borderRadius: '0 var(--radius-card) var(--radius-card) 0' }}>
        <div className="dw-grid-2" style={{ gap: 12 }}>
          <div className="dw-field">Check in<div style={{ fontSize: 17, fontWeight: 500 }}>{start ? dwFmt(start) : '—'}</div></div>
          <div className="dw-field">Check out<div style={{ fontSize: 17, fontWeight: 500 }}>{end ? dwFmt(end) : '—'}</div></div>
        </div>
        <div className="dw-field">
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Guests</span><span style={{ color: g < minG ? '#9a3b2e' : 'var(--dw-graphite)', fontWeight: 400 }}>{g} of {minG}–35</span></div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,minmax(0,1fr))', gap: 8 }}>
            {DW_PARTY.map(([k, sex, age]) => (
              <div key={k} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, background: '#fff', border: '1px solid var(--dw-smoke)', borderRadius: 10, padding: '8px 8px 8px 12px' }}>
                <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.2 }}><span style={{ fontSize: 14, fontWeight: 500 }}>{sex}</span><span style={{ fontSize: 12, fontWeight: 400, color: 'var(--dw-graphite)' }}>{age}</span></div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <button className="dw-btn dw-btn--ghost" aria-label={`Fewer ${sex} ${age}`} style={{ height: 32, width: 32, padding: 0, justifyContent: 'center' }} onClick={() => bump(k, -1)} disabled={!party[k]}>−</button>
                  <span style={{ fontSize: 17, fontWeight: 500, minWidth: 22, textAlign: 'center' }}>{party[k]}</span>
                  <button className="dw-btn dw-btn--ghost" aria-label={`More ${sex} ${age}`} style={{ height: 32, width: 32, padding: 0, justifyContent: 'center' }} onClick={() => bump(k, 1)} disabled={g >= 35}>+</button>
                </div>
              </div>
            ))}
          </div>
        </div>
        <label className="dw-field">Catering
          <select value={meal} onChange={(e) => setMeal(e.target.value)}>
            {DW_MEALS.map(([k, l, p]) => <option key={k} value={k}>{l}{p ? ` (+${gbp(p)} pp/night)` : ''}</option>)}
          </select>
        </label>
        <ul className="dw-list" style={{ fontSize: 15 }}>
          <li><span>{mode === 'exclusive' ? `Whole house × ${nights} night${nights === 1 ? '' : 's'}` : `${g} guests × ${nights} night${nights === 1 ? '' : 's'}`}</span><span>{gbp(stay)}</span></li>
          <li><span>Catering</span><span>{gbp(food)}</span></li>
          <li style={{ fontWeight: 600, fontSize: 18 }}><span>Total</span><span>{gbp(stay + food)}</span></li>
        </ul>
        <Btn arrow disabled={!ok} onClick={() => setHandoff(true)} style={{ justifyContent: 'center' }}>{ok ? 'Continue to YHA checkout' : g < minG ? `Add guests (min ${minG})` : start && !end ? 'Choose check-out date' : `Choose dates (min ${minNights} night${minNights > 1 ? 's' : ''})`}</Btn>
        <div className="dw-caption" style={{ fontSize: 13 }}>Indicative prices. Final price and payment on yha.org.uk.</div>
      </div>
    </div>
  );
}

Object.assign(window, { BookingWidget, Calendar, gbp, DW_PRICES, DW_MEALS });
