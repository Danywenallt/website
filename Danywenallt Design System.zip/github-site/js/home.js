const DW_FACTS = [['35', 'guests, whole house to yourselves'], ['16+', 'for serviced group stays'], ['0 min', 'from the door to the trails'], ['LOtC', 'Quality Badge accredited']];

function HeroA({ go }) {
  return (
    <section style={{ position: 'relative', height: 'min(92vh, 860px)', minHeight: 600, color: 'var(--dw-cream)' }}>
      <Photo id="hero-valley" label="Hero: farmhouse in the valley" radius={false} style={{ position: 'absolute', inset: 0 }} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,rgba(28,53,42,.45) 0%,rgba(28,53,42,0) 30%,rgba(28,53,42,0) 45%,rgba(28,53,42,.75) 100%)', pointerEvents: 'none' }}></div>
      <div className="dw-wrap" style={{ position: 'absolute', left: 0, right: 0, bottom: 64, display: 'flex', flexDirection: 'column', gap: 28, pointerEvents: 'none' }}>
        <div className="dw-eyebrow">Brecon Beacons, Wales</div>
        <h1 className="dw-h1" style={{ maxWidth: 980 }}>Base Camp, Wales.<br />Adventure starts at the door.</h1>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', pointerEvents: 'auto' }}>
          <Btn kind="light" arrow onClick={() => go('prices')}>Check availability</Btn>
          <Btn kind="ghost" onClick={() => go('stay')}>See the house</Btn>
        </div>
      </div>
    </section>
  );
}

function Facts() {
  return (
    <div className="dw-grid-4" style={{ borderTop: '1px solid var(--dw-smoke)', paddingTop: 32 }}>
      {DW_FACTS.map(([n, l]) => <div key={l} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}><div className="dw-h3">{n}</div><div className="dw-caption">{l}</div></div>)}
    </div>
  );
}

function ComfortAdventure() {
  const col = (id, label, title, items) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <Photo id={id} label={label} style={{ aspectRatio: '4/3' }} />
      <h3 className="dw-h4">{title}</h3>
      <ul className="dw-list dw-body">{items.map((i) => <li key={i}>{i}</li>)}</ul>
    </div>
  );
  return (
    <section className="dw-section">
      <div className="dw-wrap" style={{ display: 'flex', flexDirection: 'column', gap: 56 }}>
        <div className="dw-split">
          <h2 className="dw-h2">Comfort that backs the adventure.</h2>
          <p className="dw-lead" style={{ color: 'var(--dw-graphite)' }}>Original stonework, characterful beams and an old fireplace to come back to. Wooded slopes, high peaks and waterfalls to head out into. Rest and exploration, side by side.</p>
        </div>
        <div className="dw-grid-2" style={{ gap: 40 }}>
          {col('home-lounge', 'Lounge with fireplace', 'Come back to', ['Bunk-bedded rooms, kept together for your group', 'Dining room, lounge and garden', 'Self-catering kitchen or full-board meals', 'Drying room and cycle store'])}
          {col('home-activity', 'Walkers on the trail', 'Head out into', ['Waterfall walks and Beacons summits', 'Cycling the Taff Trail from the door', 'Sailing, boating and horse riding nearby', 'Climbing and zip line at Llangorse'])}
        </div>
      </div>
    </section>
  );
}

function Audiences({ go }) {
  const items = [
    ['aud-friends', 'Friends & families', 'Unplug together, reconnect with what matters.', 'Shared meals, open landscapes and a whole house that is yours.'],
    ['aud-teams', 'Teams & colleagues', 'Build team spirit away from the desk.', 'Days on the hills, evenings round one big table.'],
    ['aud-schools', 'Schools', 'Learn, adventure, discover.', 'LOtC-accredited, practical and affordable — with the classroom outside.'],
  ];
  return (
    <section className="dw-section" style={{ background: 'var(--dw-cloud)' }}>
      <div className="dw-wrap" style={{ display: 'flex', flexDirection: 'column', gap: 48 }}>
        <h2 className="dw-h2" style={{ maxWidth: 760 }}>One basecamp, every kind of group.</h2>
        <div className="dw-grid-3">
          {items.map(([id, t, h, b]) => (
            <div key={id} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <Photo id={id} label={t} style={{ aspectRatio: '4/5' }} />
              <div className="dw-eyebrow" style={{ color: 'var(--dw-sage)', marginTop: 8 }}>{t}</div>
              <h3 className="dw-h4" style={{ fontSize: 'clamp(22px,2.2cqw,28px)' }}>{h}</h3>
              <p className="dw-body" style={{ color: 'var(--dw-graphite)' }}>{b}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function BookBand({ go }) {
  return (
    <section className="dw-section--tight">
      <div className="dw-wrap">
        <div style={{ background: 'var(--dw-green)', color: 'var(--dw-cream)', borderRadius: 'var(--radius-card)', overflow: 'hidden', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))' }}>
          <div style={{ padding: 'clamp(28px,4cqw,56px)', display: 'flex', flexDirection: 'column', gap: 24, justifyContent: 'center' }}>
            <h2 className="dw-h3">Plan your next group escape.</h2>
            <p className="dw-body" style={{ opacity: .85 }}>Exclusive hire for up to 35, or a serviced group stay from 16.</p>
            <div><Btn kind="light" arrow onClick={() => go('prices')}>Check availability</Btn></div>
          </div>
          <Pattern tone="cream" style={{ minHeight: 280 }} />
        </div>
      </div>
    </section>
  );
}

function Home({ go }) {
  return (
    <>
      <HeroA go={go} />
      <section className="dw-section--tight" style={{ paddingTop: 72 }}><div className="dw-wrap"><Facts /></div></section>
      <ComfortAdventure />
      <Audiences go={go} />
      <BookBand go={go} />
    </>
  );
}

Object.assign(window, { Home, BookBand, Facts });
